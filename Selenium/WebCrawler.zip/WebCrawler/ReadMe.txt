Install Python 2.7

In command line...

Add python.exe to $PATH

CD to Selenium-2.44.0

Enter the following command:
python setup.py install

The script currently works with Chrome and Firefox, but not with IE. YAY. 